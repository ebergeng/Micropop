
pygame.quit()