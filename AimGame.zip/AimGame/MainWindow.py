import pygame
from pygame.locals import *
import random
import time
pygame.init()

SIZE = (2560, 1440)
DISPLAYSURF = pygame.display.set_mode((SIZE), FULLSCREEN)
mainLoop = True
red = (255, 0, 0)
white = (255, 255, 255)
pygame.mouse.set_cursor(*pygame.cursors.broken_x)


randx = 1280
randy = 720
print ("dette er randy ", randy)
print ("dette er randx ", randx)

while mainLoop:
    for event in pygame.event.get():
        

        if event.type == pygame.QUIT:
            mainLoop = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            mx, my = pygame.mouse.get_pos()
            musx = mx
            musy = my
            pygame.draw.circle(DISPLAYSURF, white, pos, 5)

            print ("dette er musx ", musx)
            #print("dette er randx ", randx)
            if musx > randx and musx < randx + 50 and musy > randy and musy < randy + 50:
                randx = random.randint(1,2500)
                randy = random.randint(1,1400)
                DISPLAYSURF.fill((0, 0, 0))
                pygame.draw.rect(DISPLAYSURF, red, (randx, randy, 50, 50))

                print("dette er randx ", randx)
        elif event.type == pygame.KEYDOWN:
            mainLoop = False
    #pygame.draw.rect(DISPLAYSURF, red,(100, 300, 50, 50))
    pygame.draw.circle(DISPLAYSURF, white, (1280,720), 20)
    pygame.display.update()
mx = 0
my = 0
pygame.quit()